export class Form {
    public name: string;
    public sex: 'Man';
    public age: number;
    public phone: number|'';
    public adress: string;
}
