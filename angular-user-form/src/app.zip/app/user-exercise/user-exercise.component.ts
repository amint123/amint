import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-exercise',
  templateUrl: './user-exercise.component.html',
  styleUrls: ['./user-exercise.component.css']
})
export class UserExerciseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
